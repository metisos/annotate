chrome.runtime.onInstalled.addListener(()=>{chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}).catch(()=>{})});
//# sourceMappingURL=service-worker.ts-GydF49ca.js.map
